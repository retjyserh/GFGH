## About
H is a small program which, upon execution, prints the lowercase letter `h` (ASCII character 104).

## Usage
1.	`make`
2.	`./h`

