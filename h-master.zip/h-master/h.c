#include <stdio.h>

int
main(int argc, char *argv[])
{	
	printf("h\n");
	
	return 0;
}

